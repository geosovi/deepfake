from django.http import JsonResponse
from .ml_model import model
import numpy as np
from django.shortcuts import render

def predict(request):
    try:
        input_data = request.GET.get('input', '')
        input_array = np.array([float(i) for i in input_data.split(',')])
        input_array = input_array.reshape(1, 64, 64, 3)  # Adjust shape as needed
        
        prediction = model.predict(input_array)
        result = prediction.argmax(axis=1).tolist()
        
        return JsonResponse({'prediction': result})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)


def index(request):
    return render(request, 'mlapp/index.html')


